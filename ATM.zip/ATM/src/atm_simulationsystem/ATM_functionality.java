package atm_simulationsystem;

import java.util.Scanner;

public class ATM_functionality {
	float balance;
	int atmpin=9344;
	
	public void pin() {
		System.out.println("Enter your PIN : ");
		Scanner scan=new Scanner(System.in);
		int enterpin=scan.nextInt();
		if(enterpin==atmpin) {
			System.out.println("Welcome..!");
			Menu();
			
		}
		else{ 
			System.out.println("Incorrect PIN");
			pin();
				
		}
	
	}
	

	private void Menu() {
    System.out.println("Choose the correct option..");
    System.out.println("press 1: Check Account Balance");
    System.out.println("press 2 : Deposite Money");
    System.out.println("press 3 : Withdraw Money");
    System.out.println("press 4 : Exit");
    Scanner scan=new Scanner(System.in);
    int option=scan.nextInt();
    switch(option){
    case 1:
    	CheckAccountBalance();
    	Menu();
    	break;
    case 2:
    	DepositMoney();
    	Menu();
    	break;
    case 3:
    	WithdrawMoney();
    	Menu();
    	break;
    case 4:
    	Exit();
    	Menu();
    	break;
    	default :
    		System.out.println("Choose the correct option..");
    		Menu();
    
    					
    }
    
	}

	

	private void WithdrawMoney() {
		System.out.println("Enter the Amount :  ");
		Scanner scan=new Scanner(System.in);
		float Amount= scan.nextFloat();
		if(Amount>balance) {
			System.out.println("Insufficient Balance or Invalid Amount..");
			
		
		}else {
			balance-=Amount;
			System.out.println("Please Collect Your Cash..");
		}
	}

	private void DepositMoney() {
		System.out.println("Enter Amount to Deposit : ");
		Scanner scan=new Scanner(System.in);
		float Amount=scan.nextFloat();
		balance += Amount;
	}

	private void CheckAccountBalance() {
		System.out.println("Your Current Balance is : " +balance);
		
	}
	
	private void Exit() {
		System.out.println(" Are you sure to Exit (Yes/NO)");
		Scanner scan=new Scanner(System.in);
		String str = scan.nextLine();
		if(str.equalsIgnoreCase("yes")) 
		{
			System.out.println("Thank You For Visiting...");
		
		} 
		else {
			Menu();
		}
		
	}
	

}
