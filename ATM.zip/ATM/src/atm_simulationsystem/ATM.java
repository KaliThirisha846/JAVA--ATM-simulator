package atm_simulationsystem;

public class ATM {
	public static void main(String[] args) {
		ATM_functionality obj=new ATM_functionality();
		obj.pin();
	}

}
